// module.exports = {
//     mongoDBUrl : 'mongodb+srv://priyanka68464gaba:Piya2227%40@cluster0.nck5gbd.mongodb.net/?retryWrites=true&w=majority',
    
//     database: 'sample_geospatial'

    module.exports = {
        mongoDBUrl: 'mongodb+srv://priyanka68464gaba:Piya2227%40@cluster0.nck5gbd.mongodb.net/sample_geospatial?retryWrites=true&w=majority',
        secret: 'eggwhitesonly',
        database_name: 'sample_geospatial'
    
    
}